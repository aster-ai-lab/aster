import React, { useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { Workbook } from '@fortune-sheet/react';
import '@fortune-sheet/react/dist/index.css';
const sheets = [
  { id: 'raw', name: '原始数据', status: 1, order: 0, row: 20, column: 8, celldata: [{r:0,c:0,v:{v:12,m:'12',ct:{fa:'General',t:'n'}}}] },
  { id: 'monthly', name: '月度汇总', status: 0, order: 1, row: 20, column: 8, celldata: [{r:0,c:0,v:{v:34,m:'34',ct:{fa:'General',t:'n'}}}] }
];
function Preview() {
  const ref = useRef(null);
  Object.defineProperty(window, 'workbook', {configurable:true,get:()=>ref.current});
  return <div style={{height:600,width:1100}}><Workbook ref={ref} data={sheets} lang={new URLSearchParams(location.search).get('lang') || 'zh'} /></div>;
}
createRoot(document.getElementById('root')!).render(<Preview />);
