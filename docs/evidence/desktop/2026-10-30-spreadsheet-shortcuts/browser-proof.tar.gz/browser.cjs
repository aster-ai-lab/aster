const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {chromium, webkit, expect} = require('@playwright/test');
const phase=process.argv[2];
assert(['before','after'].includes(phase));
const out=path.join(__dirname,phase);fs.mkdirSync(out,{recursive:true});
const expected=[
 '切换表格焦点锁定：⇧ + Ctrl + F。','选择范围：⇧ + 方向键。',
 '从首个单元格向下自动填充：Ctrl / ⌘ + D。','从首个单元格向右自动填充：Ctrl / ⌘ + R。',
 '加粗文本：Ctrl / ⌘ + B。','复制：Ctrl / ⌘ + C。','粘贴：Ctrl / ⌘ + V。',
 '撤销：Ctrl / ⌘ + Z。','重做：Ctrl / ⌘ + ⇧ + Z。','删除单元格内容：删除键或退格键。',
 '确认编辑并向下移动：回车键。','向右移动：制表键。','向左移动：⇧ + 制表键。'
];
(async()=>{
 const results=[];
 for(const [engineName,engine] of [['chromium',chromium],['webkit',webkit]]){
 const browser=await engine.launch({headless:true});
 try{for(const lang of ['zh','en']){
 const page=await browser.newPage({viewport:{width:1200,height:720},locale:lang==='zh'?'zh-CN':'en-US'});
 const pageErrors=[];page.on('pageerror',e=>pageErrors.push(String(e)));
 const result={engine:engineName,lang,failures:[]};
 try{
 await page.goto(`http://127.0.0.1:4398/target/issue212/index.html?lang=${lang}`);
 const help=page.getByRole('region',{name:lang==='zh'?'键盘快捷键':'Keyboard shortcuts'});
 await expect(help).toBeAttached();
 result.shortcuts=await help.getByRole('listitem').allTextContents();
 result.alerts=await page.getByRole('alert').allTextContents();
 result.data=await page.evaluate(()=>window.workbook.getAllSheets().map(s=>({id:s.id,name:s.name,status:s.status,order:s.order,value:s.data?.[0]?.[0]?.v})));
 const check=(name,fn)=>{try{fn()}catch(e){result.failures.push({name,error:String(e)});}};
 check('13 shortcuts',()=>assert.equal(result.shortcuts.length,13));
 check('sheet fidelity',()=>assert.deepEqual(result.data,[{id:'raw',name:'原始数据',status:1,order:0,value:12},{id:'monthly',name:'月度汇总',status:0,order:1,value:34}]));
 if(lang==='zh'){
 check('translated shortcuts',()=>assert.deepEqual(result.shortcuts,expected));
 check('focus introduction',()=>assert(result.alerts.some(t=>t.includes('请使用 ⇧ + Ctrl + F。'))));
 await help.focus();
 await page.keyboard.press('Control+Shift+F');
 await expect(page.getByRole('alert').filter({hasText:'工作表焦点锁定已禁用。'})).toHaveCount(1);
 await page.keyboard.press('Control+Shift+F');
 await expect(page.getByRole('alert').filter({hasText:'已启用工作表焦点锁定。'})).toHaveCount(1);
 result.ctrlShiftFToggles=true;
 }else if(phase==='after'){
 const baseline=JSON.parse(fs.readFileSync(path.join(__dirname,'before',`${engineName}-${lang}.json`),'utf8'));
 check('English help unchanged',()=>assert.deepEqual({shortcuts:result.shortcuts,alerts:result.alerts},{shortcuts:baseline.shortcuts,alerts:baseline.alerts}));
 }
 check('no page errors',()=>assert.deepEqual(pageErrors,[]));
 fs.writeFileSync(path.join(out,`${engineName}-${lang}.aria.txt`),await page.locator('body').ariaSnapshot());
 await page.screenshot({path:path.join(out,`${engineName}-${lang}.png`)});
 }catch(e){result.failures.push({name:'browser flow',error:String(e)});}
 finally{result.pageErrors=pageErrors;await page.close();}
 fs.writeFileSync(path.join(out,`${engineName}-${lang}.json`),JSON.stringify(result,null,2)+'\n');results.push(result);
 }}finally{await browser.close();}
 }
 fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(results,null,2)+'\n');
 console.log(JSON.stringify(results.map(({engine,lang,failures,ctrlShiftFToggles,pageErrors})=>({engine,lang,failures,ctrlShiftFToggles,pageErrors}))));
 if(results.some(r=>r.failures.length)) process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
