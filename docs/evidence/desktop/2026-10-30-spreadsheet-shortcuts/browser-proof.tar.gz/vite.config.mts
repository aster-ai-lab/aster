import { defineConfig } from 'vite';
import { resolve } from 'node:path';
const studio = resolve(import.meta.dirname, '../..');
const office = resolve(studio, '../../packages/office');
export default defineConfig({
 root: studio,
 cacheDir: resolve(import.meta.dirname, 'vite-cache'),
 resolve: {dedupe:['react','react-dom'],alias:{
 '@fortune-sheet/react':resolve(office,'node_modules/@fortune-sheet/react'),
 '@fortune-sheet/core':process.env.ISSUE212_CORE_DIR || resolve(office,'node_modules/@fortune-sheet/core')
 }},
 optimizeDeps:{entries:[resolve(import.meta.dirname,'index.html')],include:['@fortune-sheet/react','@fortune-sheet/core']},
 server:{host:'127.0.0.1',port:4398,strictPort:true,fs:{allow:[resolve(studio,'../..')]}}
});
