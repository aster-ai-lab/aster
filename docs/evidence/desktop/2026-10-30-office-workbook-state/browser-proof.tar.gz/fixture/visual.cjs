const fs=require('node:fs');const path=require('node:path');const {chromium,webkit,expect}=require('@playwright/test');
const dir='/Users/roylin/code/aster/target/github-goal-20261030/office-browser-final/visual';fs.mkdirSync(dir,{recursive:true});
(async()=>{const results=[];for(const[name,engine]of[['chromium',chromium],['webkit',webkit]]){const b=await engine.launch();try{
 const p=await b.newPage({viewport:{width:1200,height:820},locale:'zh-CN'});const errors=[];p.on('pageerror',e=>errors.push(String(e)));
 await p.addInitScript(()=>{window.paintedText=[];const original=CanvasRenderingContext2D.prototype.fillText;CanvasRenderingContext2D.prototype.fillText=function(...args){if(window.paintedText.length<2000)window.paintedText.push(String(args[0]));return Reflect.apply(original,this,args);};});
 await p.goto('http://127.0.0.1:4400/target/office-issues/index.html');const tab=p.getByRole('button',{name:'月度汇总',exact:true});await expect(tab).toBeVisible({timeout:60000});
 await p.evaluate(()=>{window.paintedText=[];});await tab.click();await expect(tab).toHaveAttribute('aria-current','true');await p.mouse.click(188,225);
 await expect(p.getByRole('textbox',{name:'当前单元格输入',exact:true})).toHaveText('330');
 await expect.poll(()=>p.evaluate(()=>window.paintedText.includes('330')&&window.paintedText.includes('210'))).toBe(true);
 await p.screenshot({path:path.join(dir,name+'-monthly.png')});fs.writeFileSync(path.join(dir,name+'-monthly.aria.txt'),await p.locator('body').ariaSnapshot());expect(errors).toEqual([]);
 results.push({engine:name,activeSheet:'月度汇总',cell:'B2',value:'330',paintedText:await p.evaluate(()=>window.paintedText),errors});
 }finally{await b.close();}}fs.writeFileSync(path.join(dir,'results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results.map(({paintedText,...r})=>({...r,paintedValues:['330','210']}))));})().catch(e=>{console.error(e);process.exitCode=1});
