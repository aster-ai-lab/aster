from pathlib import Path
import hashlib,json,subprocess
studio=Path.cwd()
source=studio/'src/renderer/pages/documents/OfficeDocumentSurface.tsx'
candidate=source.read_bytes()
baseline=subprocess.check_output(['git','show','d97043d7d4c3593428cd78680e48ff9b1422ef92:src/renderer/pages/documents/OfficeDocumentSurface.tsx'])
assert candidate!=baseline
source.parent.exists()
(studio/'target/office-issues/OfficeDocumentSurface.candidate.tsx').write_bytes(candidate)
receipt={'baselineStudioCommit':'d97043d7d4c3593428cd78680e48ff9b1422ef92','baselineHostSha256':hashlib.sha256(baseline).hexdigest(),'candidateHostSha256':hashlib.sha256(candidate).hexdigest(),'sameOfficeBundleBeforeAfter':True}
for name in ['react.js','core.js','office-kernel.wasm']:
 data=(studio/'../../packages/office/dist'/name).read_bytes()
 receipt[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
receipt['officeBundleFiles']=[{'path':p.relative_to(studio/'../../packages/office/dist').as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted((studio/'../../packages/office/dist').rglob('*')) if p.is_file() and p.suffix in {'.js','.wasm','.css'}]
receipt['browserScriptSha256']=hashlib.sha256((studio/'target/office-issues/browser.cjs').read_bytes()).hexdigest()
receipt['fixtureSha256']=hashlib.sha256((studio/'target/office-issues/fixture.xlsx').read_bytes()).hexdigest()
try:
 source.write_bytes(baseline)
 with Path('/Users/roylin/code/aster/target/github-goal-20261030/office-issues-browser-before-final.log').open('wb')as log:
  result=subprocess.run(['node','target/office-issues/browser.cjs','before'],stdout=log,stderr=subprocess.STDOUT)
 receipt['baselineExitCode']=result.returncode
finally:
 source.write_bytes(candidate)
 receipt['candidateRestored']=source.read_bytes()==candidate
 (studio/'target/office-issues/baseline-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
