import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import i18next from 'i18next';
import { I18nextProvider } from 'react-i18next';
import zhCn from '@renderer/i18n/locales/zh-cn.json';
import '@renderer/assets/styles/index.css';
import '@renderer/assets/styles/tailwind.css';
import { OfficeDocumentSurface } from '@renderer/pages/documents/OfficeDocumentSurface';
const i18n=i18next.createInstance();
await i18n.init({lng:'zh-CN',fallbackLng:'zh-CN',resources:{'zh-CN':{translation:zhCn}},interpolation:{escapeValue:false}});
function Preview(){
 const [bytes,setBytes]=useState<Uint8Array|null>(null);
 const [dirty,setDirty]=useState(false);
 const [mode,setMode]=useState('success');
 const [pending,setPending]=useState(false);
 const [error,setError]=useState('');
 useEffect(()=>{fetch('/target/office-issues/fixture.xlsx').then(r=>r.arrayBuffer()).then(b=>setBytes(new Uint8Array(b)));},[]);
 return <main style={{height:760,width:1180,display:'flex',flexDirection:'column',background:'white',color:'#171717'}}>
  <div role="group" aria-label="文件写入测试边界" style={{display:'flex',gap:16}}>
   <button onClick={()=>setMode('success')}>正常写入</button><button onClick={()=>setMode('fail')}>写入失败</button>
   <output aria-label="宿主修改状态">{dirty?'未保存':'已保存'}</output><output aria-label="写入状态">{pending?'正在写入':error}</output>
  </div>
  {bytes&&<OfficeDocumentSurface surface="spreadsheet" frame="workspace" bytes={bytes} fileName="issue209-211.xlsx" onOfficeDirty={setDirty}
   onSave={async(next)=>{setPending(true);try{if(mode==='fail'){setError('写入失败');throw new Error('Synthetic file write failure');}window.savedFile=Array.from(next);setBytes(next);setError('');}finally{setPending(false);}}}/>}
 </main>;
}
createRoot(document.getElementById('root')!).render(<I18nextProvider i18n={i18n}><Preview/></I18nextProvider>);
