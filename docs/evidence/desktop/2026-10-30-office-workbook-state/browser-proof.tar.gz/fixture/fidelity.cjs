const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');const crypto=require('node:crypto');const{createRequire}=require('node:module');
const XLSX=createRequire(path.resolve(__dirname,'../../../../packages/office/package.json'))('xlsx');
const base=process.env.OFFICE_ISSUE_OUTPUT_ROOT||__dirname;
const fixture=path.join(__dirname,'fixture.xlsx');const original=XLSX.readFile(fixture);const names=original.SheetNames;
const cells=w=>Object.fromEntries(w.SheetNames.map(n=>[n,Object.fromEntries(Object.entries(w.Sheets[n]).filter(([k,c])=>!k.startsWith('!')&&c.v!==undefined).map(([k,c])=>[k,{value:c.v,type:c.t,...(c.f?{formula:c.f}:{})}]))]));
const expected=cells(original);assert.equal(Object.values(expected).reduce((n,s)=>n+Object.keys(s).length,0),27);expected['原始数据'].C2={value:'121',type:'s'};
const files=[];
for(const engine of ['chromium','webkit'])for(const scenario of ['save','failed-save']){
 const p=path.join(base,'after',engine+'-'+scenario+'.xlsx');const wb=XLSX.readFile(p);assert.deepEqual(wb.SheetNames,names);assert.deepEqual(cells(wb),expected);
 const rows=wb.SheetNames.map(n=>XLSX.utils.sheet_to_json(wb.Sheets[n],{header:1,raw:true,blankrows:false}).length);assert.deepEqual(rows,[7,3]);
 files.push({file:engine+'-'+scenario+'.xlsx',bytes:fs.statSync(p).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),sheetNames:wb.SheetNames,populatedCells:27,populatedRowsIncludingHeaders:rows,ranges:wb.SheetNames.map(n=>wb.Sheets[n]['!ref'])});
}
fs.writeFileSync(path.join(base,'workbook-fidelity.json'),JSON.stringify({fixtureSha256:crypto.createHash('sha256').update(fs.readFileSync(fixture)).digest('hex'),sourceRanges:names.map(n=>original.Sheets[n]['!ref']),explicitEdit:{sheet:'原始数据',cell:'C2',value:'121',type:'s'},allOtherCellsUnchanged:true,files},null,2)+'\n');
console.log('Reopened 4 saved workbooks: 2 ordered sheets, 27 populated cells, 6 detail records; only the explicit C2 text edit differs.');
