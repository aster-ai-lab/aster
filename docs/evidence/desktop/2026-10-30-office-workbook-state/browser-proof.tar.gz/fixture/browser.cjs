const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {chromium,webkit,expect}=require('@playwright/test');
const phase=process.argv[2];assert(['before','after'].includes(phase));
const out=path.join(process.env.OFFICE_ISSUE_OUTPUT_ROOT||__dirname,process.env.OFFICE_ISSUE_RECEIPT||phase);fs.mkdirSync(out,{recursive:true});
async function goTo(page,reference){
 await page.getByRole('region',{name:'表格工作区',exact:true}).getByRole('main').press('Control+g');
 const dialog=page.getByRole('dialog',{name:'定位',exact:true});
 await expect(dialog).toBeVisible();
 await dialog.getByRole('textbox',{name:'引用位置',exact:true}).fill(reference);
 await dialog.getByRole('button',{name:'定位',exact:true}).click();
 await expect(dialog).toHaveCount(0);
}
async function cell(page,reference,value){
 await goTo(page,reference);
 await expect(page.locator('.fortune-name-box')).toHaveText(reference);
 await expect(page.getByRole('status',{name:'表格选区状态',exact:true})).toHaveText(reference);
 await expect(page.getByRole('textbox',{name:'当前单元格输入',exact:true})).toHaveText(value);
}
async function saveBytes(page,name){
 const bytes=await page.evaluate(()=>window.savedFile);
 assert(Array.isArray(bytes)&&bytes.length>0);
 fs.writeFileSync(path.join(out,name+'.xlsx'),Buffer.from(bytes));
}
(async()=>{
 const results=[];
 for(const [engineName,engine]of[['chromium',chromium],['webkit',webkit]].filter(([name])=>!process.env.OFFICE_ISSUE_ENGINE||name===process.env.OFFICE_ISSUE_ENGINE)){
 const browser=await engine.launch({headless:true});
 try{for(const scenario of ['sheet-tab','next-sheet','selection','save','failed-save'].filter(name=>!process.env.OFFICE_ISSUE_SCENARIO||name===process.env.OFFICE_ISSUE_SCENARIO)){
 const page=await browser.newPage({viewport:{width:1200,height:820},locale:'zh-CN'});
 const result={engine:engineName,scenario,failures:[],pageErrors:[]};
 page.on('pageerror',e=>result.pageErrors.push(String(e)));
 const key=engineName+'-'+scenario;
 const check=async(name,fn)=>{try{await fn();}catch(e){result.failures.push({name,error:String(e)});}};
 try{
 await page.goto('http://127.0.0.1:4400/target/office-issues/index.html');
 const monthly=page.getByRole('button',{name:'月度汇总',exact:true});
 const raw=page.getByRole('button',{name:'原始数据',exact:true});
 await expect(monthly).toBeVisible({timeout:60000});
 await page.mouse.click(285,225);
 await expect(page.getByRole('status',{name:'表格选区状态',exact:true})).toHaveText('C2');
 if(scenario==='sheet-tab'||scenario==='next-sheet'){
 if(scenario==='sheet-tab')await monthly.click();
 else await page.getByRole('button',{name:'下一个工作表',exact:true}).click();
 await expect(monthly).toHaveAttribute('aria-current','true');
 await cell(page,'B2','330');
 await page.getByRole('button',{name:'上一个工作表',exact:true}).click();
 await expect(raw).toHaveAttribute('aria-current','true');
 await cell(page,'C2','120');
 result.monthlyValue='330';result.rawValue='120';
 }else if(scenario==='selection'){
 await cell(page,'A25','');
 await cell(page,'C2','120');
 await page.keyboard.press('ArrowRight');
 await expect(page.locator('.fortune-name-box')).toHaveText('D2');
 await page.keyboard.press('ArrowLeft');
 await expect(page.locator('.fortune-name-box')).toHaveText('C2');
 await expect(page.getByRole('status',{name:'表格选区状态',exact:true})).toHaveText('C2');
 await expect(page.getByRole('textbox',{name:'当前单元格输入',exact:true})).toHaveText('120');
 result.consistentReference='C2';result.value='120';
 }else{
 if(scenario==='failed-save')await page.getByRole('button',{name:'写入失败',exact:true}).click();
 await page.mouse.click(285,225);
 const formula=page.getByRole('textbox',{name:'当前单元格输入',exact:true});
 await formula.fill('121');await formula.press('Enter');
 await expect(page.getByRole('status',{name:'宿主修改状态',exact:true})).toHaveText('未保存');
 result.beforeSaveHost=await page.getByRole('status',{name:'宿主修改状态',exact:true}).innerText();
 result.beforeSaveFooter=await page.getByRole('status',{name:'表格保存状态',exact:true}).allTextContents();
 await check('single authoritative save status',()=>expect(page.getByRole('status',{name:'表格保存状态',exact:true})).toHaveCount(0));
 await page.keyboard.press('Control+s');
 if(scenario==='failed-save'){
 await expect(page.getByRole('status',{name:'写入状态',exact:true})).toHaveText('写入失败');
 await expect(page.getByRole('status',{name:'宿主修改状态',exact:true})).toHaveText('未保存');
 assert.equal(await page.evaluate(()=>window.savedFile),undefined);
 await cell(page,'C2','121');
 await page.getByRole('button',{name:'正常写入',exact:true}).click();
 await page.keyboard.press('Control+s');
 result.failedWriteRetainedDraft=true;
 }
 await expect(page.getByRole('status',{name:'宿主修改状态',exact:true})).toHaveText('已保存');
 await saveBytes(page,key);
 await cell(page,'C2','121');
 result.savedValue='121';
 await page.keyboard.press('Control+z');
 await cell(page,'C2','120');
 await expect(page.getByRole('status',{name:'宿主修改状态',exact:true})).toHaveText('未保存');
 result.undoSurvivedSave=true;
 }
 }catch(e){result.failures.push({name:'browser flow',error:String(e)});}
 finally{
 result.nameBox=await page.locator('.fortune-name-box').allTextContents();
 result.selectionStatus=await page.getByRole('status',{name:'表格选区状态',exact:true}).allTextContents();
 result.activeSheets=await page.getByRole('group',{name:'工作表列表',exact:true}).getByRole('button').evaluateAll(bs=>bs.filter(b=>b.getAttribute('aria-current')==='true').map(b=>b.textContent));
 fs.writeFileSync(path.join(out,key+'.aria.txt'),await page.locator('body').ariaSnapshot());
 await page.screenshot({path:path.join(out,key+'.png')});
 await page.close();
 }
 if(result.pageErrors.length)result.failures.push({name:'page errors',error:JSON.stringify(result.pageErrors)});
 fs.writeFileSync(path.join(out,key+'.json'),JSON.stringify(result,null,2)+'\n');results.push(result);
 }}finally{await browser.close();}
 }
 fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(results,null,2)+'\n');
 console.log(JSON.stringify(results.map(({engine,scenario,failures})=>({engine,scenario,failures}))));
 if(results.some(r=>r.failures.length))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
