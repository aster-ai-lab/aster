import { TooltipProvider } from '@a3s-lab/ui'
import i18n from 'i18next'
import { createRoot } from 'react-dom/client'
import { initReactI18next } from 'react-i18next'

import { ComposerRecordingControl } from '../../src/renderer/components/composer/recording/ComposerRecordingControl'
import { ComposerScreenshotControl } from '../../src/renderer/components/composer/screenshot/ComposerScreenshotControl'
import translations from '../../src/renderer/i18n/locales/zh-cn.json'

import '../../src/renderer/assets/styles/index.css'
import '../../src/renderer/assets/styles/tailwind.css'
i18n
  .use(initReactI18next)
  .init({ lng: 'zh-CN', keySeparator: false, resources: { 'zh-CN': { translation: translations } } })
  .then(() => {
    createRoot(document.getElementById('root')!).render(
      <TooltipProvider>
        <div className="flex items-center gap-1" style={{ padding: 40 }}>
          <ComposerScreenshotControl onCapture={() => {}} />
          <ComposerRecordingControl onCapture={() => {}} />
        </div>
      </TooltipProvider>
    )
  })
