import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'

import { flowDesignerResolveAlias } from '../../scripts/flowDesignerAlias'

export default defineConfig({
  root: '/Users/roylin/code/aster/work/capture-publish-main/apps/studio',
  plugins: [tailwindcss()],
  resolve: {
    dedupe: ['react', 'react-dom'],
    alias: {
      ...flowDesignerResolveAlias('/Users/roylin/code/aster/work/capture-publish-main/apps/studio'),
      '@a3s-lab/ui/icons/providers': '/Users/roylin/code/aster/work/capture-publish-main/packages/ui/src/components/icons/providers',
      '@a3s-lab/ui/icons': '/Users/roylin/code/aster/work/capture-publish-main/packages/ui/src/components/icons',
      '@a3s-lab/ui': '/Users/roylin/code/aster/work/capture-publish-main/packages/ui/src',
      '@a3s-lab/office/react': '/Users/roylin/code/aster/work/capture-publish-main/packages/office/dist/react.js',
      '@a3s-lab/office/core': '/Users/roylin/code/aster/work/capture-publish-main/packages/office/dist/core.js',
      '@a3s-lab/office/styles.css': '/Users/roylin/code/aster/work/capture-publish-main/packages/office/dist/styles.css',
      '@a3s-lab/office': '/Users/roylin/code/aster/work/capture-publish-main/packages/office/dist/index.js',
      '@a3s-lab/intelligent-ui/json-render': '/Users/roylin/code/aster/work/capture-publish-main/packages/intelligent-ui/src/jsonRender.ts',
      '@a3s-lab/intelligent-ui': '/Users/roylin/code/aster/work/capture-publish-main/packages/intelligent-ui/src/IntelligentUI.tsx',
      '@renderer': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/src/renderer',
      '@shared': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/src/shared',
      '@data': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/src/renderer/data',
      '@logger': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/src/renderer/services/LoggerService',
      '@cherrystudio/ai-core/provider': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/packages/aiCore/src/core/providers',
      '@cherrystudio/ai-core/built-in/plugins': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/packages/aiCore/src/core/plugins/built-in',
      '@cherrystudio/ai-core': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/packages/aiCore/src',
      '@cherrystudio/extension-table-plus': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/packages/extension-table-plus/src',
      '@cherrystudio/ai-sdk-provider': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/packages/ai-sdk-provider/src',
      '@cherrystudio/provider-registry/node': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/packages/provider-registry/src/registry-loader',
      '@cherrystudio/provider-registry': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/packages/provider-registry/src',
      ahooks: '/Users/roylin/code/aster/work/capture-publish-main/packages/ui/node_modules/ahooks',
      'react-router-dom': '/Users/roylin/code/aster/work/capture-publish-main/apps/studio/src/renderer/shims/react-router-dom.tsx'
    }
  },
  server: {
    host: '127.0.0.1',
    port: 4407,
    strictPort: true,
    fs: { allow: ['/Users/roylin/code/aster', '/Users/roylin/code/aster/work/capture-publish-main/apps/studio'] }
  },
  worker: { format: 'es' }
})
