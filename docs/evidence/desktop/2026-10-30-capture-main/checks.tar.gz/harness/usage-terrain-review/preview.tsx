import { SegmentedControl, TooltipProvider } from '@a3s-lab/ui'
import i18n from 'i18next'
import { StrictMode, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { initReactI18next } from 'react-i18next'

import translations from '../../src/renderer/i18n/locales/zh-cn.json'
import { UsageActivityTerrain } from '../../src/renderer/pages/settings/UsageSettings/UsageActivityTerrain'

import '../../src/renderer/assets/styles/tailwind.css'

const days = Array.from({ length: 371 }, (_, index) => {
  const date = new Date(2025, 10, 2 + index)
  const key = date.toISOString().slice(0, 10)
  const value = index % 13 === 0 ? 100 : index % 5 === 0 ? 25 : 0
  return { key, date, value, isOutsideRange: index >= 365, label: `${key} · ${value} Token` }
})
function Preview() {
  const [view, setView] = useState<'perspective' | 'top'>('perspective')
  return (
    <TooltipProvider>
      <main style={{ maxWidth: 1080, margin: '24px auto', padding: 16, border: '1px solid #ddd', borderRadius: 12 }}>
        <div className="mb-3 flex justify-between">
          <span>每日活动</span>
          <SegmentedControl
            size="sm"
            value={view}
            onValueChange={setView}
            options={[
              { value: 'perspective', label: '3D 视图' },
              { value: 'top', label: '顶视图' }
            ]}
          />
        </div>
        <UsageActivityTerrain days={days} view={view} />
      </main>
    </TooltipProvider>
  )
}
i18n
  .use(initReactI18next)
  .init({ lng: 'zh-CN', keySeparator: false, resources: { 'zh-CN': { translation: translations } } })
  .then(() =>
    createRoot(document.getElementById('root')!).render(
      <StrictMode>
        <Preview />
      </StrictMode>
    )
  )
